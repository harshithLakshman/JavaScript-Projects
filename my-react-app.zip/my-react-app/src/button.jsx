function Button(){
    

    
 
    return(
        <div>
            <button id="btn" onClick={document.getElementById("btn").innerHTML='OOPS'}>Click me</button>
        </div>
    );
}

const handleClick=()=>{document.getElementById("btn");}
document.getElementById("btn").addEventListener('click',handleClick);


// const handleClick=()=>{
//     console.log("OUCHH!")
// }
// let count=0;
// const handleClick2=(name)=>{
//     if(count<3){
//         count++;
//         console.log(`${name} you clicked me ${count} time/s`)
        
        
//     }
//     else{
//         console.log(`stop clicking me ${name}`)
//     }
// }




export default Button