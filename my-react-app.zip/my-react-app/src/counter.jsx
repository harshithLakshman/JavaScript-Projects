import React, {useState} from "react";


function Counter(){

    const [count,setCount]=useState(0);

    const increment=()=>{
        setCount(count+1);
    }

    const decrement=()=>{
        setCount(count-1);
    }

    const reset=()=>{
        setCount(0);
    }

    return(
            <div id="container">
                <p id="displayCount">{count}</p>
                <div id="counter-btn">
                    <div className="btn"><button onClick={increment}>Increment</button></div>
                    <div className="btn"><button onClick={reset}>Reset</button></div>
                    <div className="btn"><button onClick={decrement}>Decrement</button></div>
                </div>
            </div>

        

    );

}

export default Counter